"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import type { ImportJob, ProgressEvent } from "@/lib/types";
import type { PreflightReport } from "@/components/import/Preflightdialog";
import { createImportWebSocket, getImportJob, instance as api } from "@/lib/api";

interface UseImportProgressOptions {
  jobId: string | null;
  onComplete?: (job: ImportJob) => void;
  onError?: (error: string) => void;
}

export function useImportProgress({
  jobId,
  onComplete,
  onError,
}: UseImportProgressOptions) {
  const [job, setJob] = useState<ImportJob | null>(null);
  const [connected, setConnected] = useState(false);
  const [preflightReport, setPreflightReport] = useState<PreflightReport | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const retryRef = useRef(0);
  const jobIdRef = useRef<string | null>(null);

  const connect = useCallback(
    (id: string) => {
      if (wsRef.current) wsRef.current.close();

      const ws = createImportWebSocket(id);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        retryRef.current = 0;
      };

      ws.onmessage = (e) => {
        try {
          const event: ProgressEvent & { preflightReport?: PreflightReport } =
            JSON.parse(e.data);

          // Mise à jour partielle — on garde tous les champs existants
          // et on écrase seulement ceux présents dans le payload WS
          setJob((prev) => ({
            // Valeurs par défaut pour les champs numériques
            // évite les undefined → toLocaleString() crash
            id: event.jobId,
            data_type: prev?.data_type ?? ("" as ImportJob["data_type"]),
            original_filename: prev?.original_filename ?? "",
            file_size: prev?.file_size ?? 0,
            sales_point_id: prev?.sales_point_id ?? null,
            sales_point_name: prev?.sales_point_name ?? null,
            created_at: prev?.created_at ?? null,
            updated_at: prev?.updated_at ?? null,
            errors: prev?.errors ?? [],
            pending_conflicts: prev?.pending_conflicts ?? [],
            // Champs mis à jour par le WS
            status: event.status,
            progress: event.progress ?? prev?.progress ?? 0,
            total_rows: event.totalRecords ?? prev?.total_rows ?? 0,
            processed_rows: event.processedRecords ?? prev?.processed_rows ?? 0,
            success_rows: event.successfulRecords ?? prev?.success_rows ?? 0,
            error_rows: event.failedRecords ?? prev?.error_rows ?? 0,
            timeline: event.timeline ?? prev?.timeline ?? [],
          }));

          // Rapport preflight
          if (event.preflightReport) {
            setPreflightReport(event.preflightReport);
          }
          if (event.status === "processing" && !event.preflightReport) {
            setPreflightReport(null);
          }

          // Job terminé → fetch complet pour avoir errors, conflicts, etc.
          if (event.status === "completed") {
            getImportJob(event.jobId).then((fullJob) => {
              setJob(fullJob);
              onComplete?.(fullJob);
            });
            ws.close(1000, "completed");
          }

          if (event.status === "failed") {
            getImportJob(event.jobId).then(setJob);
            onError?.(event.error ?? "Import échoué");
            ws.close(1000, "failed");
          }
        } catch (err) {
          console.error("WS parse error", err);
        }
      };

      ws.onclose = (e) => {
        setConnected(false);
        // Reconnexion uniquement si fermeture non-propre et job non terminal
        if (e.code !== 1000 && retryRef.current < 5) {
          const delay = Math.pow(2, retryRef.current) * 1000;
          retryRef.current++;
          setTimeout(() => connect(id), delay);
        }
      };

      ws.onerror = () => setConnected(false);
    },
    [onComplete, onError]
  );

  useEffect(() => {
    if (!jobId) return;
    jobIdRef.current = jobId;

    // Charge l'état initial via REST avant d'ouvrir le WS
    // → garantit que tous les champs sont présents dès le premier rendu
    getImportJob(jobId)
      .then((fullJob) => {
        setJob(fullJob);
        // Si le job est déjà terminal, pas besoin d'ouvrir le WS
        if (fullJob.status === "completed" || fullJob.status === "failed") {
          if (fullJob.status === "completed") onComplete?.(fullJob);
          if (fullJob.status === "failed") onError?.("Import échoué");
          return;
        }
        connect(jobId);
      })
      .catch(console.error);

    return () => {
      wsRef.current?.close(1000, "component unmount");
    };
  }, [jobId, connect, onComplete, onError]);

  const sendResolveConflict = useCallback(
    (rowIndex: number, decision: "update" | "skip") => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({ action: "resolve_conflict", row_index: rowIndex, decision })
        );
      }
    },
    []
  );

  const sendPreflightDecision = useCallback(
    async (decision: "auto_create" | "cancel") => {
      if (!jobIdRef.current) return;
      await api.post(`/import/${jobIdRef.current}/preflight-decision/`, { decision });
    },
    []
  );

  return { job, connected, preflightReport, sendResolveConflict, sendPreflightDecision };
}