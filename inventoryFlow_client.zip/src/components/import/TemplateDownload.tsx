"use client";

import { Download } from "lucide-react";
import { getTemplateUrl } from "@/lib/api";
import type { DataType } from "@/lib/types";
import { DATA_TYPE_LABELS } from "@/lib/types";
import { Button } from "@/components/ui/button";

interface TemplateDownloadProps {
  dataType: DataType | null;
}

export function TemplateDownload({ dataType }: TemplateDownloadProps) {
  if (!dataType) return null;

  return (
    <div className="flex items-center justify-between rounded-lg border border-dashed border-border bg-muted/30 px-4 py-3">
      <div>
        <p className="text-sm font-medium text-foreground">
          Template {DATA_TYPE_LABELS[dataType]}
        </p>
        <p className="text-xs text-muted-foreground">
          CSV avec en-têtes et exemple de ligne
        </p>
      </div>
      <a href={getTemplateUrl(dataType)} download>
        <Button variant="outline" size="sm">
          <Download size={13} />
          Télécharger
        </Button>
      </a>
    </div>
  );
}
