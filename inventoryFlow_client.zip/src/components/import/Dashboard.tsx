"use client";

import { useEffect, useState } from "react";
import {
  TrendingUp,
  CheckCircle2,
  XCircle,
  GitMerge,
  FileSpreadsheet,
} from "lucide-react";
import { getImportHistory } from "@/lib/api";
import type { ImportJob } from "@/lib/types";
import { DATA_TYPE_LABELS } from "@/lib/types";
import { cn, formatRelativeTime } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { STATUS_CONFIG } from "@/lib/utils";

export function Dashboard() {
  const [jobs, setJobs] = useState<ImportJob[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getImportHistory()
      .then(setJobs)
      .catch(() => setJobs(MOCK))
      .finally(() => setLoading(false));
  }, []);

  const completed = jobs.filter((j) => j.status === "completed");
  const failed = jobs.filter((j) => j.status === "failed");
  const totalRows = jobs.reduce((s, j) => s + j.success_rows, 0);
  const totalConflicts = jobs.reduce((s, j) => {
    const c = typeof j.pending_conflicts === "number" ? j.pending_conflicts : (j.pending_conflicts as unknown[]).length;
    return s + c;
  }, 0);

  const stats = [
    {
      label: "Imports réussis",
      value: completed.length,
      icon: CheckCircle2,
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      label: "Lignes importées",
      value: totalRows.toLocaleString(),
      icon: TrendingUp,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Échecs",
      value: failed.length,
      icon: XCircle,
      color: "text-destructive",
      bg: "bg-destructive/10",
    },
    {
      label: "Conflits totaux",
      value: totalConflicts,
      icon: GitMerge,
      color: "text-warning",
      bg: "bg-warning/10",
    },
  ];

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-24 animate-shimmer shimmer-bg rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-4">
              <div className={cn("mb-3 inline-flex h-8 w-8 items-center justify-center rounded-lg", s.bg)}>
                <s.icon size={16} className={s.color} />
              </div>
              <p className={cn("text-2xl font-bold tabular-nums", s.color)}>
                {s.value}
              </p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent jobs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Imports récents</CardTitle>
        </CardHeader>
        <CardContent>
          {jobs.length === 0 ? (
            <p className="py-6 text-center text-xs text-muted-foreground">
              Aucun import
            </p>
          ) : (
            <div className="space-y-3">
              {jobs.slice(0, 6).map((job) => {
                const cfg = STATUS_CONFIG[job.status];
                return (
                  <div key={job.id} className="flex items-center gap-3">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
                      <FileSpreadsheet size={13} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-foreground">
                        {job.original_filename}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {DATA_TYPE_LABELS[job.data_type]}
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1">
                      <Badge
                        variant={
                          job.status === "completed"
                            ? "success"
                            : job.status === "failed"
                            ? "destructive"
                            : "outline"
                        }
                      >
                        <span className={cn("h-1.5 w-1.5 rounded-full", cfg.dot)} />
                        {cfg.label}
                      </Badge>
                      <span className="text-[10px] text-muted-foreground">
                        {formatRelativeTime(job.created_at)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

const MOCK: ImportJob[] = [
  {
    id: "m1", data_type: "product", status: "completed", progress: 100,
    total_rows: 1240, processed_rows: 1240, success_rows: 1238, error_rows: 2,
    errors: [], pending_conflicts: 0, original_filename: "produits_juin.xlsx",
    file_size: 245760, created_at: new Date(Date.now() - 3600000).toISOString(), updated_at: null,
  },
  {
    id: "m2", data_type: "client", status: "completed", progress: 100,
    total_rows: 320, processed_rows: 320, success_rows: 315, error_rows: 5,
    errors: [], pending_conflicts: 3, original_filename: "clients_douala.csv",
    file_size: 45120, created_at: new Date(Date.now() - 10800000).toISOString(), updated_at: null,
  },
  {
    id: "m3", data_type: "supplier", status: "failed", progress: 40,
    total_rows: 85, processed_rows: 34, success_rows: 30, error_rows: 4,
    errors: [], pending_conflicts: 0, original_filename: "fournisseurs.xlsx",
    file_size: 32768, created_at: new Date(Date.now() - 28800000).toISOString(), updated_at: null,
  },
];
