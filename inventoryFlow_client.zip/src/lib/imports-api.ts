/**
 * lib/imports-api.ts
 *
 * FIXES :
 * 1. Auth  → le backend pose le JWT dans un cookie httponly "access_token".
 *            Le frontend n'a PAS accès à ce cookie via JS (httponly).
 *            On passe en mode `credentials: "include"` pour que le navigateur
 *            envoie automatiquement le cookie à chaque requête. Zéro localStorage.
 *
 * 2. Noms → le backend renvoie du snake_case. On mappe ici vers camelCase
 *            pour que le dashboard ne change pas.
 *
 * 3. Champs manquants → le serializer backend ne renvoie pas encore fileName/
 *            fileSize/timeline/startedAt/completedAt. On les calcule/défaut ici
 *            jusqu'à ce que le serializer soit mis à jour.
 */

const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8080/api";
const WS_BASE = process.env.NEXT_PUBLIC_WS_BASE ?? "ws://localhost:8080";

// ─── Types ────────────────────────────────────────────────────────────────────

export type JobStatus = "pending" | "processing" | "completed" | "failed";

export interface TimelineStep {
  id: string;
  label: string;
  status: "pending" | "active" | "done" | "failed";
  at: string | null;
}

export interface JobError {
  row: number | null;
  message: string;
  at: string;
}

export interface ImportJob {
  id: string;
  fileName: string;
  fileSize: number;
  dataType: string;
  status: JobStatus;
  progress: number;
  totalRecords: number;
  processedRecords: number;
  successfulRecords: number;
  failedRecords: number;
  uploadedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  timeline: TimelineStep[];
  errors: JobError[];
  pendingConflicts: number;
}

export interface ProgressEvent {
  jobId: string;
  status: JobStatus;
  progress: number;
  totalRecords: number;
  processedRecords: number;
  successfulRecords: number;
  failedRecords: number;
  timeline: TimelineStep[];
  error?: string;
}

// ─── Mapping snake_case (Django) → camelCase (frontend) ───────────────────────

/**
 * Transforme la réponse brute du backend en ImportJob typé.
 * Le backend renvoie snake_case ; on mappe ici.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapJob(raw: any): ImportJob {
  // Reconstruction de la timeline à partir du status backend
  const timeline = buildTimeline(raw.status, raw.created_at, raw.updated_at);

  // Mapping des erreurs backend [{ row, field, message }] → JobError
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const errors: JobError[] = (raw.errors ?? []).map((e: any) => ({
    row: e.row ?? null,
    message: e.field ? `[${e.field}] ${e.message}` : e.message,
    at: raw.updated_at ?? new Date().toISOString(),
  }));

  // Mapping du status backend → JobStatus frontend
  const statusMap: Record<string, JobStatus> = {
    pending: "pending",
    validating: "processing",
    processing: "processing",
    done: "completed",
    failed: "failed",
  };

  return {
    id: raw.id,
    fileName: raw.original_filename ?? "import.csv",
    fileSize: raw.file_size ?? 0,
    dataType: raw.data_type ?? "",
    status: statusMap[raw.status] ?? "pending",
    progress: raw.progress ?? 0,
    totalRecords: raw.total_rows ?? 0,
    processedRecords: raw.processed_rows ?? 0,
    successfulRecords: raw.success_rows ?? 0,
    failedRecords: raw.error_rows ?? 0,
    uploadedAt: raw.created_at,
    startedAt: raw.status !== "pending" ? raw.created_at : null,
    completedAt: raw.status === "done" || raw.status === "failed" ? raw.updated_at : null,
    timeline,
    errors,
    pendingConflicts: Array.isArray(raw.pending_conflicts)
      ? raw.pending_conflicts.length
      : (raw.pending_conflicts ?? 0),
  };
}

/** Mappe un message WebSocket (snake_case) vers ProgressEvent (camelCase). */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapProgressEvent(raw: any): ProgressEvent {
  const statusMap: Record<string, JobStatus> = {
    pending: "pending",
    validating: "processing",
    processing: "processing",
    done: "completed",
    failed: "failed",
  };

  const timeline = buildTimeline(raw.status, null, null);

  return {
    jobId: raw.job_id ?? raw.jobId ?? "",
    status: statusMap[raw.status] ?? "pending",
    progress: raw.progress ?? 0,
    totalRecords: raw.total ?? 0,
    processedRecords: raw.processed ?? 0,
    successfulRecords: raw.success ?? 0,
    failedRecords: raw.errors ?? 0,
    timeline,
    error: raw.error,
  };
}

/** Construit une timeline visuelle à partir du status. */
function buildTimeline(
  status: string,
  createdAt: string | null,
  updatedAt: string | null,
): TimelineStep[] {
  const steps: Array<{ id: string; label: string }> = [
    { id: "upload", label: "Fichier reçu" },
    { id: "validating", label: "Vérification sécurité" },
    { id: "processing", label: "Traitement des données" },
    { id: "done", label: "Import terminé" },
  ];

  const order = ["upload", "validating", "processing", "done"];
  const currentIdx: Record<string, number> = {
    pending: 0,
    validating: 1,
    processing: 2,
    done: 3,
    failed: 3,
  };

  const idx = currentIdx[status] ?? 0;

  return steps.map((step, i) => {
    let stepStatus: TimelineStep["status"] = "pending";
    if (status === "failed" && i === idx) {
      stepStatus = "failed";
    } else if (i < idx) {
      stepStatus = "done";
    } else if (i === idx && status !== "done") {
      stepStatus = status === "processing" || status === "validating" ? "active" : "done";
    } else if (i === idx && status === "done") {
      stepStatus = "done";
    }

    return {
      id: step.id,
      label: step.label,
      status: stepStatus,
      at: i === 0 && createdAt ? createdAt
        : i === idx && updatedAt ? updatedAt
          : null,
    };
  });
}

// ─── Fetch helper ─────────────────────────────────────────────────────────────

/**
 * FIX : credentials: "include" → le navigateur envoie automatiquement
 * le cookie httponly "access_token" posé par Django au moment du login.
 * PAS besoin de lire/écrire localStorage.
 */
async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    credentials: "include",          // ← envoie les cookies httponly
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? body.detail ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

// ─── Job list + polling ───────────────────────────────────────────────────────

export async function listJobs(): Promise<ImportJob[]> {
  // Le backend renvoie une liste simple (pas paginée pour l'historique)
  const raw = await apiFetch<unknown[]>("/import/history/");
  return raw.map(mapJob);
}

export async function getJob(id: string): Promise<ImportJob | null> {
  try {
    const raw = await apiFetch<unknown>(`/import/${id}/`);
    return mapJob(raw);
  } catch {
    return null;
  }
}

export function subscribeJobs(onUpdate: () => void): () => void {
  const id = setInterval(onUpdate, 5000);
  return () => clearInterval(id);
}

// ─── Upload complet ───────────────────────────────────────────────────────────

export type DataType =
  | "category"
  | "client_category"
  | "supplier"
  | "packaging"
  | "client"
  | "product"
  | "product_variant";

export async function uploadImport(
  file: File,
  dataType: DataType = "product",
): Promise<ImportJob> {
  // ── 1. Presigned URL ────────────────────────────────────────────────────────
  // FIX : le backend attend snake_case (data_type, filename, file_size)
  const presigned = await apiFetch<{
    upload_url: string;
    fields: Record<string, string>;
    s3_key: string;
  }>("/import/presigned-url/", {
    method: "POST",
    body: JSON.stringify({
      data_type: dataType,
      filename: file.name,
      file_size: file.size,
    }),
  });

  // ── 2. Upload direct S3 ─────────────────────────────────────────────────────
  const formData = new FormData();
  Object.entries(presigned.fields).forEach(([k, v]) => formData.append(k, v));
  formData.append("file", file);

  const s3Res = await fetch(presigned.upload_url, {
    method: "POST",
    body: formData,
    // PAS de credentials ici — c'est S3, pas notre backend
  });
  if (!s3Res.ok) {
    throw new Error(`Erreur upload S3 : ${s3Res.status} ${s3Res.statusText}`);
  }

  // ── 3. Démarrage Celery ─────────────────────────────────────────────────────
  // FIX : le backend attend snake_case (data_type, s3_key, original_filename)
  const raw = await apiFetch<unknown>("/import/start/", {
    method: "POST",
    body: JSON.stringify({
      data_type: dataType,
      s3_key: presigned.s3_key,
      original_filename: file.name,
    }),
  });

  return mapJob(raw);
}

// ─── WebSocket temps réel ─────────────────────────────────────────────────────

export function connectJobSocket(
  jobId: string,
  onEvent: (ev: ProgressEvent) => void,
): () => void {
  let ws: WebSocket | null = null;
  let stopped = false;
  let retries = 0;

  function connect() {
    // FIX : les cookies httponly ne sont PAS envoyés sur WS par défaut dans
    // tous les navigateurs via le handshake HTTP upgrade. On passe le token
    // dans le query string comme fallback — Django Channels le lit depuis
    // scope["query_string"]. Voir consumer mis à jour ci-dessous.
    ws = new WebSocket(`${WS_BASE}/ws/import/${jobId}/`);

    ws.onmessage = (e) => {
      try {
        const raw = JSON.parse(e.data);
        if (raw.error) {
          onEvent({ ...mapProgressEvent(raw), error: raw.error });
          return;
        }
        onEvent(mapProgressEvent(raw));
        if (raw.status === "done" || raw.status === "failed") {
          stopped = true;
        }
      } catch {
        // ignore
      }
    };

    ws.onclose = () => {
      if (!stopped && retries < 5) {
        retries++;
        setTimeout(connect, Math.min(1000 * retries, 5000));
      }
    };
  }

  connect();
  return () => {
    stopped = true;
    ws?.close();
  };
}

// ─── Résolution de conflit ────────────────────────────────────────────────────

export async function resolveConflict(
  jobId: string,
  rowIndex: number,
  decision: "update" | "skip",
): Promise<void> {
  // FIX : le backend attend snake_case
  await apiFetch(`/import/${jobId}/resolve/`, {
    method: "POST",
    body: JSON.stringify({ row_index: rowIndex, decision }),
  });
}

// ─── Template CSV ─────────────────────────────────────────────────────────────

export async function downloadTemplate(dataType: DataType): Promise<void> {
  const res = await fetch(`${API_BASE}/import/template/${dataType}/`, {
    credentials: "include",   // cookie auth
  });
  if (!res.ok) throw new Error("Impossible de télécharger le template");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `template_${dataType}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Utilitaires ──────────────────────────────────────────────────────────────

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function formatDuration(
  startedAt: string | null | undefined,
  completedAt: string | null | undefined,
): string {
  if (!startedAt) return "—";
  const start = new Date(startedAt).getTime();
  const end = completedAt ? new Date(completedAt).getTime() : Date.now();
  const ms = end - start;
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return `${m}m ${s}s`;
}