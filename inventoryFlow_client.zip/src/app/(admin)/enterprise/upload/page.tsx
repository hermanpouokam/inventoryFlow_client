"use client";

import { useState, useCallback } from "react";
import { Menu, X } from "lucide-react";
import { ImportWizard } from "@/components/import/ImportWizard";
import { HistoryTable } from "@/components/import/HistoryTable";
import { Dashboard } from "@/components/import/Dashboard";
import type { ImportJob } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Sidebar } from "@/components/layout/Sidebar";

type Tab = "import" | "history" | "dashboard";

const TAB_TITLES: Record<Tab, { title: string; sub: string }> = {
  import: { title: "Nouvel import", sub: "Importez vos données CSV ou XLSX" },
  history: { title: "Historique", sub: "Tous vos imports passés" },
  dashboard: { title: "Vue d'ensemble", sub: "Statistiques et activité récente" },
};

export default function Home() {
  const [tab, setTab] = useState<Tab>("import");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [historyRefreshTick, setHistoryRefreshTick] = useState(0);
  const [selectedJob, setSelectedJob] = useState<ImportJob | null>(null);

  const handleJobCreated = useCallback(() => {
    setHistoryRefreshTick((t) => t + 1);
  }, []);

  const { title, sub } = TAB_TITLES[tab];

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar — desktop always visible, mobile slide-in */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 transition-transform duration-200 lg:relative lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <Sidebar
          activeTab={tab}
          onTabChange={(t) => {
            setTab(t);
            setSidebarOpen(false);
            setSelectedJob(null);
          }}
        />
      </div>

      {/* Main content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border bg-card px-4 lg:px-6">
          <button
            className="lg:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setSidebarOpen((o) => !o)}
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
          <div>
            <h1 className="text-sm font-semibold text-foreground leading-none">
              {selectedJob ? selectedJob.original_filename : title}
            </h1>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {selectedJob
                ? `Job · ${selectedJob.id.slice(0, 8)}…`
                : sub}
            </p>
          </div>
        </header>

        {/* Scrollable body */}
        <main className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-2xl px-4 py-6 lg:px-6">
            {tab === "import" && (
              <ImportWizard onJobCreated={handleJobCreated} />
            )}

            {tab === "history" && (
              <HistoryTable
                refreshTick={historyRefreshTick}
                onSelectJob={(job) => {
                  setSelectedJob(job);
                  // Could open a detail drawer here
                }}
              />
            )}

            {tab === "dashboard" && <Dashboard />}
          </div>
        </main>
      </div>
    </div>
  );
}
